  <!-- Start Header -->
  <header class="cs_site_header cs_style_1 cs_sticky_header">
      <div class="cs_main_header">
          <div class="container">
              <div class="cs_main_header_in">
                  <div class="cs_main_header_left">
                      <a class="cs_site_branding" href="#" aria-label="Home page">
                          <img src="assets/img/logo/logo.png" alt="Logo">
                      </a>
                  </div>
                  <div class="cs_main_header_right">
                      <nav class="cs_nav">
                          <div class="cs_nav_list_wrapper">
                              <div class="cs_nav_list_header">
                                  <a class="cs_site_branding" href="#" aria-label="Home page">
                                       <img src="assets/img/logo/logo.png" alt="Logo">
                                  </a>
                                  <button type="button" class="cs_close_nav" aria-label="Close menu"></button>
                              </div>
                              <ul class="cs_nav_list cs_mp_0">
                                  <li>
                                      <a href="#" class="active">Home</a>
                                  </li>

                                  <li class="menu-item-has-children">
                                      <a href="#">Top Universities</a>
                                      <ul>
                                          <li><a href="#">Manipal University Jaipur Online</a></li>
                                          <li><a href="#">NMIMS Online University</a></li>
                                          <li><a href="#">IGNOU Online University</a></li>
                                          <li><a href="#">Jain University Online</a></li>
                                          <li><a href="#">Online Lovely Professional University</a></li>
                                          <li><a href="#">VIT Online University</a></li>
                                          <li><a href="#">Uttaranchal University Online</a></li>
                                          <li><a href="#">Sikkim Manipal University Online</a></li>
                                          <li><a href="#">Sharda University Online</a></li>
                                      </ul>
                                  </li>

                                  <li class="menu-item-has-children">
                                      <a href="#">Courses</a>
                                      <ul class="sub-menu">
                                          <li><a href="#">Online MBA</a></li>
                                          <li><a href="#">Online MCA</a></li>
                                          <li><a href="#">Online M.Com</a></li>
                                          <li><a href="#">Online BBA</a></li>
                                          <li><a href="#">Online BCA</a></li>
                                          <li><a href="#">Online B.Com</a></li>
                                      </ul>
                                  </li>

                                  <li><a href="#">Scholarships</a></li>
                                  <li><a href="#">Blogs</a></li>
                                  <li><a href="#">Contact Us</a></li>
                              </ul>
                          </div>
                          <div class="cs_sidenav_overlay"></div>
                      </nav>
                      <div class="cs_header_actions">

                          <a href="" class="cs_primary_btn cs_login_btn">
                              <span class="cs_login_text">Apply Now</span>
                              <span class="cs_user_icon"><i class="ri-arrow-right-line"></i></span>
                          </a>
                          <a href="#" class="cs_header_icon_btn cs_cart_btn" aria-label="Cart">
                              <i class="ri-headphone-line"></i>
                          </a>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </header>
  <!-- End Header -->